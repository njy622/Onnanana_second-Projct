package com.mulcam.bbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
